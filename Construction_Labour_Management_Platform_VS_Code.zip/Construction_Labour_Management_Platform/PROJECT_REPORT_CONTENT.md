# Mini Project — Construction Labour Management Platform

## 1. Introduction
The Construction Labour Management Platform is a web-based application developed to simplify
the management of workers involved in construction projects. Traditional manual registers make
it difficult to maintain attendance, wage and project information. The proposed platform brings
these activities into one digital interface.

## 2. Objectives
1. Maintain a digital labour database.
2. Track workers assigned to construction projects.
3. Record daily attendance.
4. Calculate wages from working days and daily wage.
5. Monitor paid and pending payments.
6. Provide a simple dashboard for project administrators.

## 3. Modules
- Dashboard
- Labour Management
- Project Management
- Attendance Management
- Payments & Wages

## 4. Functional Requirements
- Add labour records with name, role, phone, project and wage.
- Search/filter workers.
- Display project progress.
- Mark attendance.
- Calculate payroll amount.
- Mark pending payments as paid.

## 5. Non-Functional Requirements
- Responsive user interface
- Simple navigation
- Fast client-side processing
- Easy maintenance
- Basic data persistence using LocalStorage

## 6. Hardware / Software Requirements
- Laptop/Desktop
- VS Code
- Modern web browser
- Optional Live Server extension

## 7. Future Scope
A production version can use Node.js/PHP with MySQL, secure authentication, role-based access,
cloud hosting, worker document verification, notifications and advanced payroll reports.
