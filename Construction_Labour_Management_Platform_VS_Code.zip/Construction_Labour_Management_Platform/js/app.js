const seed = {
  labour:[
    {id:1,name:"Raj Kumar",role:"Mason",phone:"9876543210",project:"Green Valley Apartments",wage:850,status:"Active",days:25,payment:"Pending"},
    {id:2,name:"Amit Rawat",role:"Electrician",phone:"9812345678",project:"City Mall Renovation",wage:950,status:"Active",days:24,payment:"Paid"},
    {id:3,name:"Vikas Sharma",role:"Carpenter",phone:"9898989898",project:"Green Valley Apartments",wage:900,status:"Active",days:23,payment:"Pending"},
    {id:4,name:"Rohit Negi",role:"Painter",phone:"9765432109",project:"River View Villa",wage:750,status:"Active",days:26,payment:"Paid"},
    {id:5,name:"Deepak Singh",role:"Helper",phone:"9988776655",project:"City Mall Renovation",wage:600,status:"Active",days:22,payment:"Pending"},
    {id:6,name:"Manoj Bisht",role:"Mason",phone:"9900112233",project:"River View Villa",wage:850,status:"Active",days:25,payment:"Paid"}
  ],
  projects:[
    {id:1,name:"Green Valley Apartments",location:"Dehradun",progress:72,workers:18,budget:8500000,status:"In Progress"},
    {id:2,name:"City Mall Renovation",location:"Haridwar",progress:48,workers:12,budget:4200000,status:"In Progress"},
    {id:3,name:"River View Villa",location:"Rishikesh",progress:86,workers:9,budget:2800000,status:"In Progress"}
  ],
  attendance:{}
};

let data = JSON.parse(localStorage.getItem("buildtrack_data")) || seed;
function save(){localStorage.setItem("buildtrack_data",JSON.stringify(data))}
function initials(name){return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase()}
function money(n){return "₹"+Number(n).toLocaleString("en-IN")}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}

function showPage(page){
  document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));
  document.getElementById(page).classList.add("active");
  document.querySelectorAll(".nav-item").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
  const titles={dashboard:"Dashboard",labour:"Labour Management",projects:"Projects",attendance:"Attendance",payments:"Payments & Wages"};
  document.getElementById("pageTitle").textContent=titles[page];
  document.getElementById("sidebar").classList.remove("open");
  render();
}
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>showPage(b.dataset.page));
document.querySelectorAll("[data-page-jump]").forEach(b=>b.onclick=()=>showPage(b.dataset.pageJump));

function renderDashboard(){
  document.getElementById("statLabour").textContent=data.labour.length;
  document.getElementById("statProjects").textContent=data.projects.length;
  const counts=getAttendanceCounts();
  document.getElementById("statPresent").textContent=counts.present;
  const pending=data.labour.filter(x=>x.payment==="Pending").reduce((s,x)=>s+x.wage*x.days,0);
  document.getElementById("statPending").textContent=money(pending);
  document.getElementById("legendPresent").textContent=counts.present;
  document.getElementById("legendAbsent").textContent=counts.absent;
  document.getElementById("legendLeave").textContent=counts.leave;
  document.getElementById("attendancePct").textContent=(data.labour.length?Math.round(counts.present/data.labour.length*100):0)+"%";
  const pct=data.labour.length?counts.present/data.labour.length*360:0;
  document.getElementById("donut").style.background=`conic-gradient(var(--green) 0deg ${pct}deg,#e9edf3 ${pct}deg 360deg)`;
  document.getElementById("projectMiniList").innerHTML=data.projects.slice(0,4).map(p=>`
    <div class="project-mini"><div class="project-icon">🏗</div><div><b>${p.name}</b><small>${p.location} · ${p.workers} workers</small><div class="progress"><i style="width:${p.progress}%"></i></div></div><b>${p.progress}%</b></div>`).join("");
  document.getElementById("recentLabour").innerHTML=data.labour.slice(-5).reverse().map(row=>labourRow(row,false)).join("");
}
function labourRow(x,actions=true){
 return `<tr><td><div class="worker"><div class="worker-avatar">${initials(x.name)}</div><div><strong>${x.name}</strong><br><small style="color:var(--muted)">${x.id?"ID #"+String(x.id).padStart(3,"0"):""}</small></div></div></td>
 <td>${x.role}</td><td>${x.phone}</td><td>${x.project}</td><td>${money(x.wage)}</td><td><span class="badge active">${x.status}</span></td>
 ${actions?`<td><button class="action-btn" onclick="deleteLabour(${x.id})">Delete</button></td>`:""}</tr>`
}
function renderLabour(){
 const q=(document.getElementById("labourSearch")?.value||"").toLowerCase(), role=document.getElementById("roleFilter")?.value||"";
 const list=data.labour.filter(x=>(x.name+" "+x.role+" "+x.project).toLowerCase().includes(q)&&(role===""||x.role===role));
 document.getElementById("labourTable").innerHTML=list.map(x=>labourRow(x,true)).join("")||`<tr><td colspan="7" style="text-align:center;padding:30px">No labour records found.</td></tr>`;
}
function renderProjects(){
 document.getElementById("projectGrid").innerHTML=data.projects.map(p=>`
 <div class="project-card"><div class="project-cover">🏗️</div><div class="project-body"><h3>${p.name}</h3><p>📍 ${p.location} · ${p.status}</p>
 <div class="project-meta"><span>Progress</span><b>${p.progress}%</b></div><div class="bar"><i style="width:${p.progress}%"></i></div>
 <div class="project-meta"><span>👷 ${p.workers} workers</span><span>Budget <b>${money(p.budget)}</b></span></div></div></div>`).join("");
}
function getStatus(id){return data.attendance[id]||"Present"}
function setStatus(id,status){data.attendance[id]=status;save();render()}
function getAttendanceCounts(){
 let c={present:0,absent:0,leave:0};data.labour.forEach(x=>{const s=getStatus(x.id).toLowerCase();c[s]=(c[s]||0)+1});return c;
}
function renderAttendance(){
 const c=getAttendanceCounts();document.getElementById("aPresent").textContent=c.present;document.getElementById("aAbsent").textContent=c.absent;document.getElementById("aLeave").textContent=c.leave;document.getElementById("aTotal").textContent=data.labour.length;
 document.getElementById("attendanceTable").innerHTML=data.labour.map(x=>{let s=getStatus(x.id);return `<tr><td><div class="worker"><div class="worker-avatar">${initials(x.name)}</div><strong>${x.name}</strong></div></td><td>${x.role}</td><td>${x.project}</td><td><span class="badge ${s.toLowerCase()}">${s}</span></td><td><button class="action-btn" onclick="setStatus(${x.id},'Present')">P</button> <button class="action-btn" onclick="setStatus(${x.id},'Absent')">A</button> <button class="action-btn" onclick="setStatus(${x.id},'Leave')">L</button></td></tr>`}).join("");
}
function renderPayments(){
 const total=data.labour.reduce((s,x)=>s+x.wage*x.days,0),paid=data.labour.filter(x=>x.payment==="Paid").reduce((s,x)=>s+x.wage*x.days,0);
 document.getElementById("payTotal").textContent=money(total);document.getElementById("payPaid").textContent=money(paid);document.getElementById("payDue").textContent=money(total-paid);
 document.getElementById("paymentsTable").innerHTML=data.labour.map(x=>{let amount=x.wage*x.days;return `<tr><td><strong>${x.name}</strong><br><small style="color:var(--muted)">${x.role}</small></td><td>${x.days}</td><td>${money(x.wage)}</td><td><b>${money(amount)}</b></td><td><span class="badge ${x.payment==="Paid"?"paid":"pending"}">${x.payment}</span></td><td>${x.payment==="Pending"?`<button class="action-btn" onclick="pay(${x.id})">Mark Paid</button>`:"✓"}</td></tr>`}).join("");
}
function render(){renderDashboard();renderLabour();renderProjects();renderAttendance();renderPayments()}

function openLabourModal(){
 const select=document.getElementById("fProject");select.innerHTML=data.projects.map(p=>`<option>${p.name}</option>`).join("");
 document.getElementById("labourForm").reset();document.getElementById("modalBackdrop").classList.add("open");
}
document.getElementById("addLabourBtn").onclick=openLabourModal;document.getElementById("quickAdd").onclick=openLabourModal;
document.getElementById("modalClose").onclick=()=>document.getElementById("modalBackdrop").classList.remove("open");
document.getElementById("modalBackdrop").onclick=e=>{if(e.target.id==="modalBackdrop")e.currentTarget.classList.remove("open")};
document.getElementById("labourForm").onsubmit=e=>{
 e.preventDefault();const id=Date.now();data.labour.push({id,name:fName.value.trim(),role:fRole.value,phone:fPhone.value.trim(),wage:Number(fWage.value),project:fProject.value,status:"Active",days:0,payment:"Pending"});
 save();document.getElementById("modalBackdrop").classList.remove("open");toast("Labour record added ✓");render();
}
window.deleteLabour=function(id){if(confirm("Delete this labour record?")){data.labour=data.labour.filter(x=>x.id!==id);save();toast("Record deleted");render()}};
window.pay=function(id){const x=data.labour.find(x=>x.id===id);x.payment="Paid";save();toast("Payment marked as paid ✓");render()};
document.getElementById("markAllBtn").onclick=()=>{data.labour.forEach(x=>data.attendance[x.id]="Present");save();toast("All workers marked present ✓");render()};
document.getElementById("payAllBtn").onclick=()=>{data.labour.forEach(x=>x.payment="Paid");save();toast("All pending wages processed ✓");render()};
document.getElementById("labourSearch").oninput=renderLabour;document.getElementById("roleFilter").onchange=renderLabour;
document.getElementById("mobileMenu").onclick=()=>document.getElementById("sidebar").classList.toggle("open");
document.getElementById("themeBtn").onclick=()=>{document.body.classList.toggle("dark");localStorage.setItem("buildtrack_dark",document.body.classList.contains("dark"))};
if(localStorage.getItem("buildtrack_dark")==="true")document.body.classList.add("dark");
document.getElementById("notifyBtn").onclick=()=>toast("No new notifications");
document.getElementById("globalSearch").onkeydown=e=>{if(e.key==="Enter"){showPage("labour");document.getElementById("labourSearch").value=e.target.value;renderLabour()}};
document.getElementById("addProjectBtn").onclick=()=>toast("Project module ready — add records in the projects array in js/app.js");
render();
