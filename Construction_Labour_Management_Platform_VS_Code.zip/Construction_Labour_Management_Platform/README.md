# BuildTrack — Construction Labour Management Platform

A responsive mini project for a BCA/Cybersecurity student, designed around the submitted
**Construction Labour Management Platform** synopsis.

## Features
- Modern responsive dashboard
- Labour/workforce management
- Search and role filtering
- Construction project progress cards
- Daily attendance: Present / Absent / Leave
- Wage and payment tracking
- LocalStorage data persistence
- Dark mode
- Mobile sidebar
- Attractive UI suitable for mini-project demonstration

## Technology Used
- HTML5
- CSS3
- JavaScript (ES6)
- Browser LocalStorage
- Google Fonts (Inter)

## Run in VS Code
1. Extract the ZIP.
2. Open the folder in VS Code.
3. Open `index.html`.
4. Recommended: install the **Live Server** extension.
5. Right-click `index.html` → **Open with Live Server**.

No database/server is required for this demo version. Data is stored in the browser using LocalStorage.

## Main Files
- `index.html` — complete application layout
- `css/style.css` — attractive responsive design
- `js/app.js` — application logic and sample data

## Suggested Viva Explanation
The system digitizes construction workforce operations. An administrator can maintain labour
records, assign workers to projects, mark attendance and calculate pending/paid wages.
JavaScript handles the application logic while LocalStorage provides lightweight client-side
persistence for the mini-project demonstration.

## Future Scope
- MySQL database + PHP/Node.js backend
- Admin/contractor login
- Worker registration and document verification
- Automatic monthly payroll
- SMS/WhatsApp notifications
- Cloud deployment
- Role-based access control
